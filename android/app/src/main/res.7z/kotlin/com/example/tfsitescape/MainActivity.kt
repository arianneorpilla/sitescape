package com.tf.sitescape

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
