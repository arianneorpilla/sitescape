package com.tf.tfsitescape

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
